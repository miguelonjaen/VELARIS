// VELARIS build-time adapter. The upstream SeaChart renderer is GPL-2.0-or-later.
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Set;
import javax.imageio.ImageIO;
import render.ChartContext;
import render.Renderer;
import s57.S57map;
import s57.S57map.Feature;
import s57.S57map.Snode;
import s57.S57osm;

public final class BatchSeamarks implements ChartContext {
    private int zoom, x, y;
    private double world;
    public Point2D getPoint(Snode node) {
        return new Point2D.Double((node.lon / (2 * Math.PI) + 0.5) * world - x * 256,
                (1 - Math.log(Math.tan(node.lat) + 1 / Math.cos(node.lat)) / Math.PI) / 2 * world - y * 256);
    }
    public double mile(Feature feature) {
        return world / (21600 * Math.cos(feature.geom.centre.lat));
    }
    public boolean clip() { return false; }
    public int grid() { return 0; }
    public Chart chart() { return new Chart(); }
    public Color background(S57map map) { return new Color(0, true); }
    public RuleSet ruleset() { return RuleSet.SEAMARK; }

    public static void main(String[] args) throws Exception {
        if (args.length != 3) throw new IllegalArgumentException("Expected OSM, jobs TSV, output directory");
        S57map map = new S57map(true);
        S57osm.OSMmap(new File(args[0]), map, false);
        S57map.FtrMap all = map.features;
        // Index only the adapter's selection. Upstream symbols/rules stay intact.
        Map<Long, S57map.FtrMap> byId = new HashMap<>();
        Map<Feature, Integer> drawOrder = new IdentityHashMap<>();
        all.forEach((type, features) -> {
            for (Feature feature : features) {
                if (drawOrder.containsKey(feature)) throw new IllegalStateException("Repeated feature identity requires original list selection");
                drawOrder.put(feature, drawOrder.size());
                byId.computeIfAbsent(feature.id, ignored -> new S57map.FtrMap())
                    .computeIfAbsent(type, ignored -> new ArrayList<>()).add(feature);
            }
        });
        List<String> jobs = Files.readAllLines(Path.of(args[1]));
        Path output = Path.of(args[2]);
        Files.createDirectories(output);
        BatchSeamarks context = new BatchSeamarks();
        int done = 0, written = 0;
        for (String job : jobs) {
            String[] columns = job.split("\\t");
            String[] xyz = columns[0].split("/");
            context.zoom = Integer.parseInt(xyz[0]);
            context.x = Integer.parseInt(xyz[1]); context.y = Integer.parseInt(xyz[2]);
            if (context.zoom < 6 || context.zoom > 16) throw new IllegalArgumentException("Unsupported zoom");
            context.world = 256 * Math.pow(2, context.zoom);
            Set<Long> ids = new HashSet<>();
            for (String id : columns[1].split(",")) ids.add(Long.parseLong(id));
            map.features = new S57map.FtrMap();
            for (Long id : ids) {
                S57map.FtrMap selected = byId.get(id);
                if (selected == null) continue;
                selected.forEach((type, features) -> map.features
                    .computeIfAbsent(type, ignored -> new ArrayList<>()).addAll(features));
            }
            // Preserve exactly the upstream list order within each object class.
            map.features.values().forEach(features -> features.sort(
                (a, b) -> Integer.compare(drawOrder.get(a), drawOrder.get(b))));
            BufferedImage image = new BufferedImage(256, 256, BufferedImage.TYPE_INT_ARGB);
            Graphics2D graphics = image.createGraphics();
            try {
                Renderer.reRender(graphics, new Rectangle(256, 256), context.zoom,
                        Math.pow(2, context.zoom - 12), map, context);
            } finally { graphics.dispose(); }
            boolean content = false;
            // TYPE_INT_ARGB stores the same alpha bits used by getRGB, without
            // a per-pixel ColorModel conversion for every empty output tile.
            for (int pixel : ((DataBufferInt) image.getRaster().getDataBuffer()).getData()) {
                if ((pixel >>> 24) != 0) { content = true; break; }
            }
            if (content) {
                ImageIO.write(image, "png", output.resolve(columns[0].replace('/', '-') + ".png").toFile());
                written++;
            }
            if (++done % 2000 == 0) System.out.println("Rendered " + done + "/" + jobs.size() + "; nonempty " + written);
        }
        System.out.println("Complete: " + done + " candidates, " + written + " transparent tiles");
    }
}
