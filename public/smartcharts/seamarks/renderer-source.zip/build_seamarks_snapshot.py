"""Build a bounded offline SeaChart package from a verified OSM XML snapshot.

Coordinates/tags are never synthesized. Rendering IDs alone are remapped to avoid
OSM namespace collisions and the upstream renderer's reserved node IDs 1..4.
"""
from pathlib import Path
import argparse,base64,collections,hashlib,json,math,subprocess,zipfile,xml.etree.ElementTree as ET
from shapely.geometry import LineString,box

def encoded(value):return json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode('utf8')
def digest(value):return hashlib.sha256(value).hexdigest()
def write(path,value):path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(encoded(value))
def build(root,archive,pack_start=1000,adapter=None):
 if not __debug__:raise RuntimeError('Validation requires Python without -O')
 source=root/'signals-source.osm';meta=json.loads((root/'source-provenance.json').read_text(encoding='utf8'))
 assert digest(source.read_bytes())==meta['sha256']
 stage=root/'staged';stage.mkdir(exist_ok=True)
 assert not (stage/'catalog.json').exists(),'Use a fresh staging directory for a new build'
 renderer=root/'renderer';renderer.mkdir(exist_ok=True)
 with zipfile.ZipFile(archive) as z:
  for name in z.namelist():
   if name.startswith('upstream/') or name=='BatchSeamarks.java':
    target=(renderer/name).resolve();assert target.is_relative_to(renderer.resolve())
    if name.endswith('/'):target.mkdir(parents=True,exist_ok=True)
    else:target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(name))
 if adapter:(renderer/'BatchSeamarks.java').write_bytes(adapter.read_bytes())
 doc=ET.parse(source).getroot();primitives={}
 for e in doc:
  if e.tag not in ('node','way','relation'):continue
  key=f'{e.tag}/{e.get("id")}';assert key not in primitives
  primitives[key]=e
 render_ids={key:-(i+10) for i,key in enumerate(primitives)}
 geometries={};active=set()
 def geometry(key):
  if key in geometries:return geometries[key]
  assert key not in active,'Cyclic OSM relation requires explicit review'
  active.add(key);e=primitives[key]
  if e.tag=='node':
   lon,lat=float(e.get('lon')),float(e.get('lat'));assert math.isfinite(lon) and math.isfinite(lat) and -180<=lon<=180 and -85<=lat<=85
   g={'type':'Point','coordinates':[lon,lat]}
  elif e.tag=='way':
   refs=['node/'+n.get('ref') for n in e.findall('nd')];assert len(refs)>=2
   g={'type':'LineString','coordinates':[geometry(ref)['coordinates'] for ref in refs]}
  else:
   refs=[f'{m.get("type")}/{m.get("ref")}' for m in e.findall('member')]
   g={'type':'GeometryCollection','geometries':[geometry(ref) for ref in refs]}
  geometries[key]=g;active.remove(key);return g
 records=[];objects=[]
 for key,e in primitives.items():
  tags={t.get('k'):t.get('v') for t in e.findall('tag')};assert len(tags)==len(e.findall('tag'))
  g=geometry(key)
  record={'id':key,'geometry':g,'properties':{'tags':tags,'version':e.get('version'),'timestamp':e.get('timestamp')}}
  records.append(record)
  if any(k.startswith('seamark:') for k in tags):
   objects.append({'id':key,'type':tags.get('seamark:type'),'geometrySha256':digest(encoded(g)),'tagSha256':digest(encoded(tags)),
    'renderIds':[render_ids[key]],'sourceVersion':e.get('version'),'sourceTimestamp':e.get('timestamp')})
 assert len(objects)==meta['objectsWithSeamarkTags']
 write(stage/'source-primitives.json',records);write(stage/'objects.json',objects)
 # Renderer input is an identity-preserving topology remap, not new nautical data.
 render_doc=ET.Element('osm',version='0.6',generator='GAULOS SeaChart offline adapter')
 west,south,east,north=meta['queriedBounds']
 ET.SubElement(render_doc,'bounds',minlat=str(south),minlon=str(west),maxlat=str(north),maxlon=str(east))
 for key,e in primitives.items():
  clone=ET.fromstring(ET.tostring(e));clone.set('id',str(render_ids[key]))
  for nd in clone.findall('nd'):nd.set('ref',str(render_ids['node/'+nd.get('ref')]))
  for member in clone.findall('member'):member.set('ref',str(render_ids[member.get('type')+'/'+member.get('ref')]))
  render_doc.append(clone)
 ET.ElementTree(render_doc).write(renderer/'signals.osm',encoding='utf-8',xml_declaration=True)
 extent=box(west,south,east,north);jobs=collections.defaultdict(set)
 def tilexy(lon,lat,z):return ((lon+180)/360*2**z,(1-math.asinh(math.tan(math.radians(lat)))/math.pi)/2*2**z)
 def lines(g):
  if g['type']=='Point':return [[g['coordinates']]]
  if g['type']=='LineString':return [g['coordinates']]
  return [line for child in g.get('geometries',[]) for line in lines(child)]
 for obj in objects:
  for coords in lines(geometries[obj['id']]):
   if len(coords)==1:
    clipped=[coords] if west<=coords[0][0]<=east and south<=coords[0][1]<=north else []
   else:
    geom=LineString(coords).intersection(extent)
    clipped=[list(geom.coords)] if geom.geom_type=='LineString' and not geom.is_empty else [list(g.coords) for g in getattr(geom,'geoms',[]) if g.geom_type=='LineString']
   for path in clipped:
    for z in range(6,17):
     points=[tilexy(*p,z) for p in path]
     for a,b in zip(points,points[1:] or points):
      steps=max(1,math.ceil(max(abs(b[0]-a[0]),abs(b[1]-a[1]))*2))
      for i in range(steps+1):
       x=math.floor(a[0]+(b[0]-a[0])*i/steps);y=math.floor(a[1]+(b[1]-a[1])*i/steps)
       for dx in (-1,0,1):
        for dy in (-1,0,1):
         if 0<=x+dx<2**z and 0<=y+dy<2**z:jobs[f'{z}/{x+dx}/{y+dy}'].add(obj['renderIds'][0])
  if len(jobs)>250000:raise RuntimeError('Tile job budget exceeded; split into reviewed regional packages')
 (renderer/'jobs.tsv').write_text(''.join(f'{key}\t{",".join(map(str,sorted(ids)))}\n' for key,ids in sorted(jobs.items())),encoding='utf8')
 print(f'Validated {len(objects)} objects, {len(records)} primitives, {len(jobs)} candidate tiles',flush=True)
 classes=renderer/'classes';classes.mkdir(exist_ok=True)
 subprocess.run(['javac','-encoding','UTF-8','-sourcepath',str(renderer/'upstream/src'),'-d',str(classes),str(renderer/'BatchSeamarks.java')],check=True)
 tiles=root/'tiles';tiles.mkdir(exist_ok=True)
 subprocess.run(['java','-Xmx768m','-Djava.awt.headless=true','-cp',str(classes),'BatchSeamarks',str(renderer/'signals.osm'),str(renderer/'jobs.tsv'),str(tiles)],check=True)
 packs={};index={};pack={};size=2;number=pack_start;png_bytes=0
 def flush():
  nonlocal pack,size,number
  if not pack:return
  name=f'seamarks-pack-{number}.json';p=stage/'packs'/name;write(p,pack)
  assert p.stat().st_size<1500000
  packs[name]={'bytes':p.stat().st_size,'sha256':digest(p.read_bytes())}
  for key in pack:index[key]=name
  number+=1;pack={};size=2
 for p in sorted(tiles.glob('*.png')):
  key=p.stem.replace('-','/');assert key in jobs
  raw=p.read_bytes();assert raw[:8]==b'\x89PNG\r\n\x1a\n' and int.from_bytes(raw[16:20],'big')==256 and int.from_bytes(raw[20:24],'big')==256 and raw[25]==6
  png_bytes+=len(raw);b64=base64.b64encode(raw).decode();length=len(encoded({key:b64}))
  if size+length>1200000:flush()
  pack[key]=b64;size+=length
 flush();assert index
 catalog={'schemaVersion':1,'experimental':True,'navigationUse':False,'officialEnc':False,'transparent':True,'scheme':'xyz','minZoom':6,'maxZoom':16,
  'bounds':meta['queriedBounds'],'coverage':'España mediterránea, Baleares, Alborán–Melilla y objetos norteafricanos dentro de la ventana consultada; inventario OSM no exhaustivo',
  'sourceTimestamp':meta['osmBaseTimestamp'],'sourceSha256':meta['sha256'],'sourceURL':meta['source'],'sourceFormat':'osm-xml','sourcePrimitivesSha256':digest((stage/'source-primitives.json').read_bytes()),
  'dataLicense':'ODbL-1.0','portrayalLicense':'GPL-2.0-or-later','attribution':'© OpenStreetMap contributors · SeaChart / Malcolm Herring',
  'renderer':{'revision':'22f394a0ea3ed5cedcfcb0b81345e8333d72adbe','license':'GPL-2.0-or-later','ruleset':'SEAMARK','sourceArchiveSha256':digest(archive.read_bytes())},
  'inputObjects':len(objects),'objectsWithoutType':sum(o['type'] is None for o in objects),'objectIndexSha256':digest((stage/'objects.json').read_bytes()),'tileCount':len(index),'pngBytes':png_bytes,'tiles':index,'packs':packs}
 catalog['coverage']=meta.get('selection',catalog['coverage'])+'; inventario comunitario no exhaustivo'
 catalog['renderer']['adapterSha256']=digest((renderer/'BatchSeamarks.java').read_bytes())
 write(stage/'catalog.json',catalog);write(stage/'source-provenance.json',meta)
 with zipfile.ZipFile(stage/'renderer-source.zip','w',zipfile.ZIP_DEFLATED) as z:
  for p in (renderer/'upstream').rglob('*'):
   if p.is_file():z.write(p,str(p.relative_to(renderer)))
  for name in ['BatchSeamarks.java','signals.osm','jobs.tsv']:z.write(renderer/name,name)
  for name in ['signals-source.osm','source-provenance.json']:z.write(root/name,name)
  z.write(Path(__file__),'build_seamarks_snapshot.py')
 print(json.dumps({'objects':len(objects),'candidateTiles':len(jobs),'tiles':len(index),'packs':len(packs),'pngBytes':png_bytes}),flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--renderer-archive',type=Path,required=True);p.add_argument('--pack-start',type=int,default=1000);p.add_argument('--batch-adapter',type=Path);a=p.parse_args();build(a.root,a.renderer_archive,a.pack_start,a.batch_adapter)
